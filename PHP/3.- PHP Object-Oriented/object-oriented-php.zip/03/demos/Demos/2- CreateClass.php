<?php

// --------------------------------
// -- Creating a Class
// --------------------------------

/*

All classes start out with the class reserved name followed 
by the name of the class after which two curly brackets are set.

Classes can contain it's own constants, variables (known as properties),
and functions (called methods)

*/

class Person
{
    
}