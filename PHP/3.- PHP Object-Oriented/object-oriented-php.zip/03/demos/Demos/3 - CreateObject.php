<?php

// --------------------------------
// -- Creating Objects
// --------------------------------

/*

An object is the type that is created when you create a new instance of a class.

*/

class Person
{
    
}

$myObj = new Person();
