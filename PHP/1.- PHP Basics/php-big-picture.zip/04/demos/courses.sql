create table courses (
	name text,
	author text,
	create_date date
);