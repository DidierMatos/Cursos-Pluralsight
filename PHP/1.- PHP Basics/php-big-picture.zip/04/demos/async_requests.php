<?php
require __DIR__ . '/vendor/autoload.php';

$global_start = microtime(true);

$client = new GuzzleHttp\Client();

$promises = [
	'1' => $client->getAsync('http://jkle.in/long_endpoint/1'),
	'2' => $client->getAsync('http://jkle.in/long_endpoint/2'),
	'3' => $client->getAsync('http://jkle.in/long_endpoint/3'),
];
sleep(2);

$results = GuzzleHttp\Promise\unwrap($promises);
$results = GuzzleHttp\Promise\settle($promises)->wait();

echo $results['1']['value']->getBody() . '</br>';
echo $results['2']['value']->getBody() . '</br>';
echo $results['3']['value']->getBody() . '</br>';

$global_end = microtime(true);

echo "Full page loaded in: " . round($global_end - $global_start, 2) . " seconds";

